import os
import json
import pymysql

from endstone import ColorFormat
from endstone.event import event_handler, PlayerLoginEvent, PlayerJoinEvent, PlayerQuitEvent
from endstone.inventory import ItemStack
from endstone.plugin import Plugin

# NBT classes may live under endstone.nbt or directly under endstone
try:
    from endstone.nbt import (
        CompoundTag, ListTag, ByteTag, ShortTag, IntTag, LongTag,
        FloatTag, DoubleTag, StringTag, ByteArrayTag, IntArrayTag,
    )
except (ImportError, AttributeError):
    from endstone import (
        CompoundTag, ListTag, ByteTag, ShortTag, IntTag, LongTag,
        FloatTag, DoubleTag, StringTag, ByteArrayTag, IntArrayTag,
    )


# ---------------------------------------------------------------------------
# NBT ↔ dict serialization helpers
# ---------------------------------------------------------------------------

def nbt_to_dict(tag):
    """Recursively convert any NBT Tag to a JSON-serializable Python object."""
    if isinstance(tag, CompoundTag):
        return {
            "_type": "compound",
            "value": {k: nbt_to_dict(v) for k, v in tag.items()}
        }
    elif isinstance(tag, ListTag):
        return {
            "_type": "list",
            "value": [nbt_to_dict(tag[i]) for i in range(tag.size())]
        }
    elif isinstance(tag, ByteTag):
        return {"_type": "byte", "value": tag.value}
    elif isinstance(tag, ShortTag):
        return {"_type": "short", "value": tag.value}
    elif isinstance(tag, IntTag):
        return {"_type": "int", "value": tag.value}
    elif isinstance(tag, LongTag):
        return {"_type": "long", "value": tag.value}
    elif isinstance(tag, FloatTag):
        return {"_type": "float", "value": tag.value}
    elif isinstance(tag, DoubleTag):
        return {"_type": "double", "value": tag.value}
    elif isinstance(tag, StringTag):
        return {"_type": "string", "value": tag.value}
    elif isinstance(tag, ByteArrayTag):
        return {"_type": "byte_array", "value": list(tag)}
    elif isinstance(tag, IntArrayTag):
        return {"_type": "int_array", "value": list(tag)}
    else:
        # Fallback — try to get a value attribute
        return {"_type": "unknown", "value": str(tag)}


def dict_to_nbt(data):
    """Recursively rebuild an NBT Tag from a dict produced by nbt_to_dict."""
    t = data.get("_type", "unknown")
    v = data.get("value")

    if t == "compound":
        tag = CompoundTag()
        for key, child in v.items():
            tag[key] = dict_to_nbt(child)
        return tag
    elif t == "list":
        tag = ListTag()
        for child in v:
            tag.append(dict_to_nbt(child))
        return tag
    elif t == "byte":
        return ByteTag(int(v))
    elif t == "short":
        return ShortTag(int(v))
    elif t == "int":
        return IntTag(int(v))
    elif t == "long":
        return LongTag(int(v))
    elif t == "float":
        return FloatTag(float(v))
    elif t == "double":
        return DoubleTag(float(v))
    elif t == "string":
        return StringTag(str(v))
    elif t == "byte_array":
        return ByteArrayTag(v)
    elif t == "int_array":
        return IntArrayTag(v)
    else:
        return StringTag(str(v))


# ---------------------------------------------------------------------------
# Item serialization / deserialization
# ---------------------------------------------------------------------------

def serialize_item(item, slot_num):
    """Serialize an ItemStack (or None/air) to a JSON-friendly dict."""
    if item is None or str(item.type) == "minecraft:air":
        return {"slot": slot_num, "type": None}

    result = {
        "slot": slot_num,
        "type": str(item.type),
        "amount": item.amount,
        "data": item.data,
    }

    # Save the full NBT compound tag — this preserves everything:
    # enchantments, lore, display name, shulker contents, damage, etc.
    try:
        nbt_tag = item.nbt
        if nbt_tag is not None:
            result["nbt"] = nbt_to_dict(nbt_tag)
    except Exception:
        pass

    return result


def deserialize_item(item_data):
    """Recreate an ItemStack from a dict produced by serialize_item."""
    if item_data.get("type") is None:
        return None

    item_type = item_data["type"]
    amount = item_data.get("amount", 1)
    data = item_data.get("data", 0)

    item = ItemStack(item_type, amount, data)

    # Restore the full NBT compound tag
    nbt_data = item_data.get("nbt")
    if nbt_data is not None:
        try:
            tag = dict_to_nbt(nbt_data)
            if isinstance(tag, CompoundTag):
                item.nbt = tag
        except Exception:
            pass

    return item


# ---------------------------------------------------------------------------
# Inventory save / load helpers
# ---------------------------------------------------------------------------

ARMOR_SLOTS = {
    -1: "helmet",
    -2: "chestplate",
    -3: "leggings",
    -4: "boots",
    -5: "item_in_off_hand",
}


def save_inventory_to_json(inv, size):
    """Serialize an entire PlayerInventory (including armor + offhand) to a JSON string."""
    items = []

    # Main inventory slots
    for i in range(size):
        items.append(serialize_item(inv.get_item(i), i))

    # Armor + offhand
    for slot_num, attr_name in ARMOR_SLOTS.items():
        items.append(serialize_item(getattr(inv, attr_name), slot_num))

    return json.dumps(items, ensure_ascii=False)


def load_inventory_from_json(json_str, inv):
    """Restore items from a JSON string into a PlayerInventory."""
    items = json.loads(json_str)

    # Clear everything first
    inv.clear()
    for attr_name in ARMOR_SLOTS.values():
        setattr(inv, attr_name, ItemStack("minecraft:air", 1))

    for item_data in items:
        slot = item_data.get("slot", 0)
        item = deserialize_item(item_data)

        if item is None:
            continue

        if slot >= 0:
            inv.set_item(slot, item)
        elif slot in ARMOR_SLOTS:
            setattr(inv, ARMOR_SLOTS[slot], item)


def save_container_to_json(container, size):
    """Serialize a generic container (e.g. ender chest) to a JSON string."""
    items = []
    for i in range(size):
        items.append(serialize_item(container.get_item(i), i))
    return json.dumps(items, ensure_ascii=False)


def load_container_from_json(json_str, container):
    """Restore items from a JSON string into a generic container."""
    items = json.loads(json_str)
    container.clear()

    for item_data in items:
        slot = item_data.get("slot", 0)
        item = deserialize_item(item_data)
        if item is not None and slot >= 0:
            container.set_item(slot, item)


# ---------------------------------------------------------------------------
# Database helper
# ---------------------------------------------------------------------------

def connect_db(host, port, user, password, db_name):
    """Open a MySQL connection and select the database."""
    conn = pymysql.connect(host=host, port=int(port), user=user, password=password)
    cursor = conn.cursor()
    cursor.execute(f"USE {db_name}")
    return conn, cursor


# ===========================================================================
# Plugin
# ===========================================================================

class InventorySharePlugin(Plugin):
    api_version = "0.11"

    def __init__(self):
        super().__init__()
        self.sql_host = ""
        self.sql_port = 0
        self.sql_user = ""
        self.sql_pass = ""
        self.sql_db_name = ""

    # -----------------------------------------------------------------------
    # Config
    # -----------------------------------------------------------------------

    def load_config(self):
        self.sql_host = self.config["sql_host"]
        self.sql_port = self.config["sql_port"]
        self.sql_user = self.config["sql_user"]
        self.sql_pass = self.config["sql_pass"]
        self.sql_db_name = self.config["sql_db_name"]

    # -----------------------------------------------------------------------
    # Login status tracking (prevents double-connection)
    # -----------------------------------------------------------------------

    def set_login_status(self, xuid, status: bool):
        """Update the player's login-status flag in the database."""
        conn, cursor = connect_db(
            self.sql_host, self.sql_port, self.sql_user,
            self.sql_pass, self.sql_db_name
        )

        cursor.execute(
            "SELECT is_logged_in FROM player_data WHERE player_xuid = %s", xuid
        )
        result = cursor.fetchone()

        if result:
            cursor.execute(
                "UPDATE player_data SET is_logged_in = %s WHERE player_xuid = %s",
                (str(status), xuid),
            )
        else:
            cursor.execute(
                "INSERT INTO player_data (player_xuid, is_logged_in) VALUES (%s, 'True')",
                xuid,
            )

        conn.commit()
        conn.close()

    def get_login_status(self, xuid) -> bool:
        """Check whether a player is flagged as logged-in on another server."""
        conn, cursor = connect_db(
            self.sql_host, self.sql_port, self.sql_user,
            self.sql_pass, self.sql_db_name
        )
        cursor.execute(
            "SELECT is_logged_in FROM player_data WHERE player_xuid = %s", xuid
        )
        result = cursor.fetchone()
        conn.close()
        return result[0] == 1 if result else False

    # -----------------------------------------------------------------------
    # Lifecycle
    # -----------------------------------------------------------------------

    def on_load(self):
        self.logger.info(
            f"{ColorFormat.AQUA}InventorySharePlugin loaded!{ColorFormat.RESET}"
        )

    def on_enable(self):
        self.logger.info(
            f"{ColorFormat.AQUA}InventorySharePlugin enabled!{ColorFormat.RESET}"
        )
        self.save_default_config()
        self.load_config()

        # Mark all currently online players as logged-in
        for player in self.server.online_players:
            self.set_login_status(player.xuid, True)

        if not os.path.exists("plugins/inventory_share_plugin/config.toml"):
            self.logger.error("config.toml not found")

        self.register_events(self)

    def on_disable(self):
        # Mark all online players as logged-out
        for player in self.server.online_players:
            self.set_login_status(player.xuid, False)

        self.logger.info(
            f"{ColorFormat.AQUA}InventorySharePlugin disabled!{ColorFormat.RESET}"
        )

    # -----------------------------------------------------------------------
    # Events
    # -----------------------------------------------------------------------

    @event_handler
    def on_player_login(self, event: PlayerLoginEvent):
        """Prevent double-login across servers."""
        self.logger.info("Login event")
        target = event.player
        conn, cursor = connect_db(
            self.sql_host, self.sql_port, self.sql_user,
            self.sql_pass, self.sql_db_name
        )

        if self.get_login_status(target.xuid):
            target.kick(
                "You cannot connect because you are already logged in on another server."
            )
            cursor.close()
            conn.close()
            return

        self.set_login_status(target.xuid, True)
        conn.commit()
        cursor.close()
        conn.close()

    @event_handler
    def on_player_join(self, event: PlayerJoinEvent):
        """Restore the player's inventory and ender chest from the database."""
        self.logger.info("Join event")
        target = event.player
        self.set_login_status(target.xuid, False)

        conn, cursor = connect_db(
            self.sql_host, self.sql_port, self.sql_user,
            self.sql_pass, self.sql_db_name
        )

        # Upsert login status
        cursor.execute(
            "SELECT is_logged_in FROM player_data WHERE player_xuid = %s",
            (target.xuid,),
        )
        result = cursor.fetchone()

        if result:
            cursor.execute(
                "UPDATE player_data SET is_logged_in = 'True' WHERE player_xuid = %s",
                (target.xuid,),
            )
        else:
            cursor.execute(
                "INSERT INTO player_data (player_xuid, is_logged_in) VALUES (%s, 'True')",
                (target.xuid,),
            )

        # --- Restore main inventory ---
        cursor.execute(
            "SELECT player_inv FROM player_data WHERE player_xuid = %s",
            (target.xuid,),
        )
        result = cursor.fetchone()

        if result and result[0]:
            try:
                player = self.server.get_player(target.name)
                load_inventory_from_json(result[0], player.inventory)
            except Exception as e:
                self.logger.error(f"Failed to restore inventory: {e}")

        # --- Restore ender chest ---
        cursor.execute(
            "SELECT player_enderchest FROM player_data WHERE player_xuid = %s",
            (target.xuid,),
        )
        result = cursor.fetchone()

        if result and result[0]:
            try:
                player = self.server.get_player(target.name)
                load_container_from_json(result[0], player.ender_chest)
            except Exception as e:
                self.logger.error(f"Failed to restore ender chest: {e}")

        cursor.close()
        conn.close()

    @event_handler
    def on_player_quit(self, event: PlayerQuitEvent):
        """Save the player's inventory and ender chest to the database."""
        target = event.player

        if self.get_login_status(target.xuid):
            self.logger.info(
                f"{target.name} was kicked (connected to another server)."
            )
            self.set_login_status(target.xuid, False)
            return

        conn, cursor = connect_db(
            self.sql_host, self.sql_port, self.sql_user,
            self.sql_pass, self.sql_db_name
        )
        cursor.execute(
            "UPDATE player_data SET is_logged_in = 'False' WHERE player_xuid = %s",
            (target.xuid,),
        )
        conn.commit()

        try:
            player = self.server.get_player(target.name)

            # Save main inventory (slots + armor + offhand)
            inv = player.inventory
            inv_json = save_inventory_to_json(inv, target.inventory.size)
            cursor.execute(
                "UPDATE player_data SET player_inv = %s WHERE player_xuid = %s",
                (inv_json, target.xuid),
            )

            # Save ender chest
            ec = player.ender_chest
            ec_json = save_container_to_json(ec, target.ender_chest.size)
            cursor.execute(
                "UPDATE player_data SET player_enderchest = %s WHERE player_xuid = %s",
                (ec_json, target.xuid),
            )

            conn.commit()
            self.logger.info(f"Saved inventory for {target.name}")

        except Exception as e:
            self.logger.error(f"Failed to save inventory: {e}")

        cursor.close()
        conn.close()